#!/usr/bin/env python

import pylauncher

pylauncher.IbrunLauncher("parallellines",cores="file",
                         debug="job+host+task+exec")
