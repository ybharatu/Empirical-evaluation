import pylauncher

pylauncher.ClassicLauncher("db_command_lines",debug="job",delay=2)
