#!/usr/bin/env python

import pylauncher

##
## This resumes a classic launcher from a queuestate file
##

pylauncher.ResumeClassicLauncher("queuestate",debug="job")
