#!/usr/bin/env python

import pylauncher

##
## Emulate the classic launcher, using a one liner
##

pylauncher.MICLauncher("commandlines",debug="job+host+task+queue+exec")

