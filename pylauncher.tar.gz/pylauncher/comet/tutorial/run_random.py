import pylauncher

pylauncher.ClassicLauncher("random_command_lines")
